const app = require("express")();
const http = require('http').Server(app);

const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://inaniyakapil2000:z0HIxUOTkF4deias@datatable.t4wicmx.mongodb.net/?retryWrites=true&w=majority&appName=dataTable');

const User  = require('./model/userModel');

async function insert()
{
    User.create({
        name:'payal',
        email:'inaiyakapil2000@gmail.com'
    })
}
insert();


http.listen(3000, function(){
    console.log('server is ruining');
});